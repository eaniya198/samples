### eks cluster iam policy
- https://docs.aws.amazon.com/ko_kr/eks/latest/userguide/service_IAM_role.html

1. cluster-trust-policy.json
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "Service": "eks.amazonaws.com"
         },
         "Action": "sts:AssumeRole"
       }
     ]
   }
   ```
2. Creates a role
    ```sh
    aws iam create-role \
        --role-name eksClusterRole \
        --assume-role-policy-document file://"cluster-trust-policy.json"
    ```
3. It links the necessary policies.
   ```sh
   aws iam attach-role-policy \
    --policy-arn arn:aws:iam::aws:policy/AmazonEKSClusterPolicy \
    --role-name eksClusterRole
   ```
### node iam policy
- https://docs.aws.amazon.com/ko_kr/eks/latest/userguide/create-node-role.html


    - AmazonEKSWorkerNodePolicy
    - AmazonEC2ContainerRegistryReadOnly
    - AmazonEKS_CNI_Policy

1. node-role-trust-relationship.json
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "Service": "ec2.amazonaws.com"
         },
         "Action": "sts:AssumeRole"
       }
     ]
   }
   ```
2. Create an IAM role.
   ```sh
   aws iam create-role \
     --role-name AmazonEKSNodeRole \
     --assume-role-policy-document file://"node-role-trust-relationship.json"
   ```
3. Attach two required IAM managed policies to the IAM role.
   ```sh
   aws iam attach-role-policy \
     --policy-arn arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy \
     --role-name AmazonEKSNodeRole
   aws iam attach-role-policy \
     --policy-arn arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly \
     --role-name AmazonEKSNodeRole
   ```

4. vpc cni
      - ipv4
      ```
      aws iam attach-role-policy \
        --policy-arn arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy \
        --role-name AmazonEKSNodeRole
      ```
      - ipv6
    ```json
    {
       "Version": "2012-10-17",
       "Statement": [
           {
               "Effect": "Allow",
               "Action": [
                   "ec2:AssignIpv6Addresses",
                   "ec2:DescribeInstances",
                   "ec2:DescribeTags",
                   "ec2:DescribeNetworkInterfaces",
                   "ec2:DescribeInstanceTypes"
               ],
               "Resource": "*"
           },
           {
               "Effect": "Allow",
               "Action": [
                   "ec2:CreateTags"
               ],
               "Resource": [
                   "arn:aws:ec2:*:*:network-interface/*"
               ]
           }
       ]
   }
   ```

      Create the IAM policy.
      ```sh
      aws iam create-policy --policy-name AmazonEKS_CNI_IPv6_Policy --policy-document file://vpc-cni-ipv6-policy.json
      ```

      Attach the IAM policy to the IAM role. Replace 111122223333 with your account ID.
      ```sh
      aws iam attach-role-policy \
        --policy-arn arn:aws:iam::111122223333:policy/AmazonEKS_CNI_IPv6_Policy \
        --role-name AmazonEKSNodeRole
      ```

### pod-execution
- https://docs.aws.amazon.com/eks/latest/userguide/pod-execution-role.html

   ```json
   {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Condition": {
          "ArnLike": {
              "aws:SourceArn": "arn:aws:eks:region-code:111122223333:fargateprofile/my-cluster/*"
          }
        },
        "Principal": {
          "Service": "eks-fargate-pods.amazonaws.com"
        },
        "Action": "sts:AssumeRole"
      }
    ]
  }
  ```

  2. Create a Pod execution IAM role.
  ```bash
   aws iam create-role \
    --role-name AmazonEKSFargatePodExecutionRole \
    --assume-role-policy-document file://"Pod-execution-role-trust-policy.json"
  ```

  3. Attach the required Amazon EKS managed IAM policy to the role.
  ```bash
   aws iam attach-role-policy \
     --policy-arn arn:aws:iam::aws:policy/AmazonEKSFargatePodExecutionRolePolicy \
     --role-name AmazonEKSFargatePodExecutionRole
  ```

### EKS connector IAM role
- https://docs.aws.amazon.com/eks/latest/userguide/connector_IAM_role.html
   ```json
  {
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Principal": {
          "Service": "ssm.amazonaws.com"
        },
        "Action": "sts:AssumeRole"
      }
    ]
  }
  ```

  2. Create a file named eks-connector-agent-policy.json that contains the following JSON to use for the IAM role.
  ```json
  {
      "Version": "2012-10-17",
      "Statement": [
          {
              "Sid": "SsmControlChannel",
              "Effect": "Allow",
              "Action": [
                  "ssmmessages:CreateControlChannel"
              ],
              "Resource": "arn:aws:eks:*:*:cluster/*"
          },
          {
              "Sid": "ssmDataplaneOperations",
              "Effect": "Allow",
              "Action": [
                  "ssmmessages:CreateDataChannel",
                  "ssmmessages:OpenDataChannel",
                  "ssmmessages:OpenControlChannel"
              ],
              "Resource": "*"
          }
      ]
  }
  ```

  3. Create the Amazon EKS Connector agent role using the trust policy and policy you created in the previous list items.

   ```bash
  aws iam create-role \
      --role-name AmazonEKSConnectorAgentRole \
      --assume-role-policy-document file://eks-connector-agent-trust-policy.json
   ```

  4. Attach the policy to your Amazon EKS Connector agent role.

  ```bash
  aws iam put-role-policy \
      --role-name AmazonEKSConnectorAgentRole \
      --policy-name AmazonEKSConnectorAgentPolicy \
      --policy-document file://eks-connector-agent-policy.json
   ```