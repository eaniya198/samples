## AWS IAM
1. aws:username
    ```
    ${aws:username}: IAM 사용자의 이름을 나타내는 변수이다. 이 변수를 사용하여 IAM 사용자의 이름을 동적으로 참조할 수 있다.
    예시:
    arn:aws:iam::123456789012:user/${aws:username}
    ```
2. aws:userid
    ```
    ${aws:userid}: IAM 사용자의 고유 식별자(User ID)를 나타내는 변수이다. 이 변수를 사용하여 IAM 사용자의 ID를 동적으로 참조할 수 있다.
    예시:
    arn:aws:iam::123456789012:user/${aws:userid}
    ```

3. aws:SourceIp
    ```
    ${aws:SourceIp}: 요청이 시작된 클라이언트의 IP 주소를 나타내는 변수입니다. 이 변수를 사용하여 특정 IP 주소를 기반으로 정책을 설정할 수 있습니다.
    예시:
    "Condition": {"IpAddress": {"aws:SourceIp": "203.0.113.0/24"}}
    ```

4. aws:UserAgent
    ```
    ${aws:UserAgent}: 요청을 시작한 클라이언트의 User-Agent 문자열을 나타내는 변수이다. 이 변수를 사용하여 특정 User-Agent를 기반으로 정책을 설정할 수 있다.
    예시:
    "Condition": {"StringEquals": {"aws:UserAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3"}}
    ```